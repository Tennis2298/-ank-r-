const menuToggle = document.querySelector('.menu-toggle');
const nav = document.querySelector('.nav');
menuToggle.addEventListener('click', () => {
  const open = nav.classList.toggle('open');
  menuToggle.setAttribute('aria-expanded', String(open));
  menuToggle.setAttribute('aria-label', open ? 'Menüyü kapat' : 'Menüyü aç');
  menuToggle.textContent = open ? '×' : '☰';
});
nav.querySelectorAll('a').forEach(link => link.addEventListener('click', () => {
  nav.classList.remove('open');
  menuToggle.setAttribute('aria-expanded', 'false');
  menuToggle.textContent = '☰';
}));

document.querySelector('.theme-toggle').addEventListener('click', () => {
  document.body.classList.toggle('night-mode');
});

document.getElementById('year').textContent = new Date().getFullYear();

const stories = {
  salt: {
    title: 'Tuz Mağarası',
    text: 'Çankırı Tuz Mağarası, bölgenin tuz üretimiyle kurduğu tarihî bağın en dikkat çekici simgelerinden biridir. Yer altındaki tuz katmanları, doğanın uzun zaman içinde oluşturduğu etkileyici bir ortam sunar. Ziyaret planlamadan önce güncel ziyaret koşullarını kontrol etmeyi unutma.'
  },
  castle: {
    title: 'Çankırı Kalesi',
    text: 'Şehre hâkim bir noktada yer alan Çankırı Kalesi, kentin tarihî siluetinin önemli parçalarındandır. Kale çevresinden görülen şehir manzarası, Çankırı’nın geçmişiyle bugünü arasında güzel bir bağ kurar.'
  },
  yaren: {
    title: 'Yaren Geleneği',
    text: 'Çankırı Yaren kültürü; sohbet, dayanışma, misafirperverlik ve ortak sorumluluk gibi değerleri yaşatmasıyla bilinir. Bu gelenek, yalnızca bir buluşma değil, toplumsal hafızayı kuşaktan kuşağa aktaran kültürel bir miras olarak görülür.'
  }
};
const dialog = document.getElementById('detail-dialog');
document.querySelectorAll('[data-detail]').forEach(button => button.addEventListener('click', () => {
  const story = stories[button.dataset.detail];
  if (!story) return;
  document.getElementById('dialog-title').textContent = story.title;
  document.getElementById('dialog-text').textContent = story.text;
  dialog.showModal();
}));
document.querySelector('.dialog-close').addEventListener('click', () => dialog.close());
document.querySelector('.dialog-ok').addEventListener('click', () => dialog.close());
dialog.addEventListener('click', event => {
  if (event.target === dialog) dialog.close();
});

document.getElementById('greet-button').addEventListener('click', () => {
  const name = document.getElementById('visitor-name').value.trim();
  const greeting = document.getElementById('greeting');
  greeting.textContent = name ? `Hoş geldin ${name}! Çankırı'nın güzelliklerini keşfetmen dileğiyle. ✨` : 'Çankırı’nın güzelliklerini keşfetmen dileğiyle! ✨';
});
document.getElementById('visitor-name').addEventListener('keydown', event => {
  if (event.key === 'Enter') document.getElementById('greet-button').click();
});
